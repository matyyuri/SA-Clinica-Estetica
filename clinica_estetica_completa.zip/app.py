from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3

app = Flask(__name__)
app.secret_key = "supersecretkey"

# Banco de Dados
DB_NAME = "clinica.db"

def init_db():
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
        """)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            procedure TEXT,
            date TEXT,
            time TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
        """)
        conn.commit()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/procedures')
def procedures():
    return render_template('procedures.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']
        try:
            with sqlite3.connect(DB_NAME) as conn:
                cursor = conn.cursor()
                cursor.execute("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
                               (name, email, password, role))
                conn.commit()
                flash('Registro realizado com sucesso!', 'success')
                return redirect(url_for('home'))
        except sqlite3.IntegrityError:
            flash('Erro: Email já registrado.', 'danger')
    return render_template('register.html')

@app.route('/appointments', methods=['GET', 'POST'])
def appointments():
    if request.method == 'POST':
        user_id = request.form['user_id']
        procedure = request.form['procedure']
        date = request.form['date']
        time = request.form['time']
        with sqlite3.connect(DB_NAME) as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO appointments (user_id, procedure, date, time) VALUES (?, ?, ?, ?)",
                           (user_id, procedure, date, time))
            conn.commit()
            flash('Agendamento realizado com sucesso!', 'success')
    with sqlite3.connect(DB_NAME) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM appointments")
        appointments = cursor.fetchall()
    return render_template('appointments.html', appointments=appointments)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
